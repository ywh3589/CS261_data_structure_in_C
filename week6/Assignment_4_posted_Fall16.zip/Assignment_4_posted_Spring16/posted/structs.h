/* You can modify the structure to store whatever you'd like in your BST */

struct data {
	int number;
	char *name;
};
